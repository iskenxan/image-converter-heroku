const serverless = require('serverless-http');
const express = require('express');
const bodyParser = require('body-parser');
const { uploadToS3 } = require('./s3');
const { createMarkedImage } = require('./canvas');

const app = express();
app.use(bodyParser.urlencoded());

app.post('/contacts/mark-existing', (req, res) => {
  const { image_url, user_id, contact_id } = req.body;
  process(image_url, user_id, contact_id, res);
});


app.post('/contacts/create-marked', (req, res) => {
  const { user_id, contact_id} = req.body;

  const imageUrl = 'blue-head.jpg';
  process(imageUrl, user_id, contact_id, res);
});


const process = (imageUrl, userId, contactId, res) => {
  createMarkedImage(imageUrl)
    .then(imageBuffer => {
      return uploadToS3(imageBuffer, userId, contactId);
    }).then(s3Data => {
    res.send(s3Data.ETag);
  }).catch(error => {
    console.log(error);
    res.status(400).send(error.message)
  });
};


app.listen(3000, () => {
  console.log('Listening on port 3000');
});

module.exports.handler = serverless(app);